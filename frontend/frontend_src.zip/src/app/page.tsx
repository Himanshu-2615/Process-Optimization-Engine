"use client";

import { useEffect, useState } from "react";
import { WorkflowGraph } from "@/components/WorkflowBuilder/WorkflowGraph";
import { KPICards } from "@/components/KPIOverview/KPICards";
import { UtilizationChart } from "@/components/Dashboard/UtilizationChart";
import { RecommendationsList } from "@/components/Dashboard/RecommendationsList";
import { SimulationForm } from "@/components/SimulationPanel/SimulationForm";
import { SimulationResults } from "@/components/SimulationPanel/SimulationResults";
import {
  api,
  type Process,
  type AnalysisResult,
  type Recommendation,
  type RiskClassification,
  type SimulationResult,
} from "@/lib/api";
import { RiskBadge } from "@/components/Dashboard/RiskBadge";
import { SensitivityPanel } from "@/components/Advanced/SensitivityPanel";
import { MonteCarloPanel } from "@/components/Advanced/MonteCarloPanel";
import { MultiScenarioPanel } from "@/components/Advanced/MultiScenarioPanel";
import { CsvUpload } from "@/components/Advanced/CsvUpload";
import { ProcessEditor } from "@/components/ProcessEditor/ProcessEditor";

export default function Home() {
  const [processes, setProcesses] = useState<Process[]>([]);
  const [selectedProcess, setSelectedProcess] = useState<Process | null>(null);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [simResult, setSimResult] = useState<SimulationResult | null>(null);
  const [risk, setRisk] = useState<RiskClassification | null>(null);
  const [revenuePerUnit, setRevenuePerUnit] = useState(500);
  const [loading, setLoading] = useState(true);
  const [analyzing, setAnalyzing] = useState(false);

  useEffect(() => {
    api
      .listProcesses()
      .then(setProcesses)
      .catch(() => setProcesses([]))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (selectedProcess) {
      api.getProcess(selectedProcess.id).then(setSelectedProcess);
    }
  }, [selectedProcess?.id]);

  const handleAnalyze = async () => {
    if (!selectedProcess) return;
    setAnalyzing(true);
    try {
      const res = await api.analyze(selectedProcess.id, revenuePerUnit);
      setAnalysis(res.analysis);
      setRecommendations(res.recommendations);
      setRisk(res.risk ?? null);
    } catch {
      setAnalysis(null);
      setRecommendations([]);
      setRisk(null);
    } finally {
      setAnalyzing(false);
    }
  };

  const bottleneckIds = new Set(
    analysis?.bottlenecks.map((b) => b.step_id) ?? []
  );
  const criticalPathSet = new Set(analysis?.critical_path ?? []);

  const handleExportPdf = () => {
    if (!selectedProcess) return;
    window.open(
      api.exportPdf(selectedProcess.id, revenuePerUnit),
      "_blank"
    );
  };

  const handleCreateSample = async () => {
    try {
      const p = await api.createProcess({
        name: "Procurement Approval Process",
        description: "Sample use case: Request to vendor allocation",
        steps: [
          {
            name: "Request Submission",
            duration_minutes: 10,
            cost_per_execution: 5,
            resource_count: 2,
            sla_limit_minutes: 15,
            executions_per_day: 50,
          },
          {
            name: "Manager Approval",
            duration_minutes: 120,
            cost_per_execution: 50,
            resource_count: 3,
            sla_limit_minutes: 90,
            executions_per_day: 50,
          },
          {
            name: "Finance Approval",
            duration_minutes: 90,
            cost_per_execution: 30,
            resource_count: 2,
            sla_limit_minutes: 120,
            executions_per_day: 50,
          },
          {
            name: "Vendor Allocation",
            duration_minutes: 60,
            cost_per_execution: 20,
            resource_count: 2,
            sla_limit_minutes: 90,
            executions_per_day: 50,
          },
        ],
        dependencies: [
          { source_step_id: 0, target_step_id: 1 },
          { source_step_id: 1, target_step_id: 2 },
          { source_step_id: 2, target_step_id: 3 },
        ],
      });
      setProcesses((prev) => [...prev, p]);
      setSelectedProcess(p);
      setAnalysis(null);
      setRecommendations([]);
      setSimResult(null);
      setRisk(null);
    } catch (e) {
      console.error(e);
      alert("Failed to create sample process");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <header className="border-b border-slate-200 bg-white/80 backdrop-blur">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <h1 className="text-xl font-bold text-slate-800">
              Process Optimization & Impact Simulation
            </h1>
            <div className="flex items-center gap-2">
              <button
                onClick={handleCreateSample}
                className="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-700"
              >
                Create Sample Process
              </button>
              <select
                value={selectedProcess?.id ?? ""}
                onChange={(e) => {
                  const id = Number(e.target.value);
                  const p = processes.find((x) => x.id === id) ?? null;
                  setSelectedProcess(p);
                  setAnalysis(null);
                  setRecommendations([]);
                  setSimResult(null);
                  setRisk(null);
                }}
                className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
              >
                <option value="">Select process...</option>
                {processes.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
              {selectedProcess && (
                <>
                  <input
                    type="number"
                    value={revenuePerUnit}
                    onChange={(e) => setRevenuePerUnit(Number(e.target.value))}
                    placeholder="Revenue/unit"
                    className="w-24 rounded-lg border border-slate-300 px-2 py-2 text-sm"
                  />
                  <button
                    onClick={handleAnalyze}
                    disabled={analyzing}
                    className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700 disabled:opacity-50"
                  >
                    {analyzing ? "Analyzing..." : "Analyze"}
                  </button>
                  <button
                    onClick={handleExportPdf}
                    className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
                  >
                    Export PDF
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
        {loading ? (
          <div className="rounded-xl border border-slate-200 bg-white p-12 text-center text-slate-500">
            Loading...
          </div>
        ) : !selectedProcess ? (
          <div className="space-y-6">
            <div className="rounded-xl border border-slate-200 bg-white p-12 text-center">
              <p className="text-slate-600">
                Create a sample process or upload a CSV to get started.
              </p>
              <button
                onClick={handleCreateSample}
                className="mt-4 rounded-lg bg-indigo-600 px-6 py-3 font-medium text-white hover:bg-indigo-700"
              >
                Create Sample Procurement Process
              </button>
            </div>
            <div className="max-w-xl">
              <CsvUpload
                onSuccess={(p) => {
                  setProcesses((prev) => [...prev, p]);
                  setSelectedProcess(p);
                  setAnalysis(null);
                  setRecommendations([]);
                  setSimResult(null);
                  setRisk(null);
                }}
              />
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <section>
              <h2 className="mb-4 text-lg font-semibold text-slate-800">
                Edit Process
              </h2>
              <ProcessEditor
                process={selectedProcess}
                onUpdate={(updated) => {
                  setSelectedProcess(updated);
                  setProcesses((prev) =>
                    prev.map((p) => (p.id === updated.id ? updated : p))
                  );
                  setAnalysis(null);
                  setRecommendations([]);
                  setRisk(null);
                }}
              />
            </section>

            <section>
              <h2 className="mb-4 text-lg font-semibold text-slate-800">
                Workflow
              </h2>
              <WorkflowGraph
                process={selectedProcess}
                bottleneckStepIds={bottleneckIds}
                criticalPathSteps={criticalPathSet}
              />
            </section>

            <section>
              <h2 className="mb-4 text-lg font-semibold text-slate-800">
                Key Performance Indicators
              </h2>
              <KPICards analysis={analysis} />
            </section>

            <div className="grid gap-6 lg:grid-cols-2">
              <section>
                <h2 className="mb-4 text-lg font-semibold text-slate-800">
                  Resource Utilization
                </h2>
                <UtilizationChart analysis={analysis} />
              </section>
              <section>
                <h2 className="mb-4 text-lg font-semibold text-slate-800">
                  Risk Classification
                </h2>
                <RiskBadge risk={risk} />
              </section>
            </div>

            <section>
              <h2 className="mb-4 text-lg font-semibold text-slate-800">
                Recommendations
              </h2>
              <RecommendationsList recommendations={recommendations} />
            </section>

            <section>
              <h2 className="mb-4 text-lg font-semibold text-slate-800">
                Advanced: Sensitivity & Monte Carlo
              </h2>
              <div className="grid gap-6 lg:grid-cols-2">
                <SensitivityPanel process={selectedProcess} revenuePerUnit={revenuePerUnit} />
                <MonteCarloPanel process={selectedProcess} revenuePerUnit={revenuePerUnit} />
              </div>
            </section>

            <section>
              <h2 className="mb-4 text-lg font-semibold text-slate-800">
                Advanced: Multi-Scenario Comparison
              </h2>
              <MultiScenarioPanel process={selectedProcess} />
            </section>

            <section>
              <h2 className="mb-4 text-lg font-semibold text-slate-800">
                Optimization Simulation
              </h2>
              <div className="grid gap-6 lg:grid-cols-2">
                <SimulationForm process={selectedProcess} onResult={setSimResult} />
                <SimulationResults result={simResult} />
              </div>
            </section>
          </div>
        )}
      </main>
    </div>
  );
}