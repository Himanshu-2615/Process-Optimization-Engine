"use client";

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
} from "recharts";
import type { AnalysisResult } from "@/lib/api";

interface UtilizationChartProps {
  analysis: AnalysisResult | null;
}

export function UtilizationChart({ analysis }: UtilizationChartProps) {
  if (!analysis) return null;

  const data = Object.entries(analysis.resource_utilization).map(([name, value]) => ({
    name: name.length > 12 ? name.slice(0, 12) + "…" : name,
    utilization: value,
    fullName: name,
  }));

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
      <h3 className="mb-4 font-semibold text-slate-800">Resource Utilization %</h3>
      <div className="h-[220px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 5, right: 5, left: 0, bottom: 30 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" tick={{ fontSize: 11 }} />
            <YAxis domain={[0, 120]} tick={{ fontSize: 11 }} />
            <Tooltip
              formatter={(v: number | undefined) => [
                v != null ? `${v.toFixed(1)}%` : "",
                "Utilization",
              ]}
              labelFormatter={(_, payload) => payload[0]?.payload?.fullName}
            />
            <ReferenceLine y={85} stroke="#dc2626" strokeDasharray="4 4" />
            <Bar
              dataKey="utilization"
              fill="#6366f1"
              radius={[4, 4, 0, 0]}
              fillOpacity={0.8}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
      <p className="mt-2 text-xs text-slate-500">
        Red line: 85% threshold. Above = over-utilized.
      </p>
    </div>
  );
}
