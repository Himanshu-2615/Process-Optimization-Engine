"use client";

import type { Recommendation } from "@/lib/api";

interface RecommendationsListProps {
  recommendations: Recommendation[];
}

export function RecommendationsList({ recommendations }: RecommendationsListProps) {
  if (recommendations.length === 0) {
    return (
      <div className="rounded-xl border border-slate-200 bg-white p-6 text-center text-slate-500">
        No recommendations. Process looks healthy.
      </div>
    );
  }

  const priorityColor = (p: string) => {
    if (p === "high") return "bg-red-100 text-red-800";
    if (p === "medium") return "bg-amber-100 text-amber-800";
    return "bg-slate-100 text-slate-800";
  };

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
      <h3 className="mb-4 font-semibold text-slate-800">Recommendations</h3>
      <ul className="space-y-3">
        {recommendations.map((r, i) => (
          <li
            key={i}
            className="rounded-lg border border-slate-100 bg-slate-50 p-3"
          >
            <div className="flex items-center gap-2">
              <span
                className={`rounded px-2 py-0.5 text-xs font-medium ${priorityColor(r.priority)}`}
              >
                {r.priority}
              </span>
              <span className="font-medium text-slate-800">{r.title}</span>
            </div>
            <p className="mt-1 text-sm text-slate-600">{r.description}</p>
            <p className="mt-1 text-sm italic text-slate-500">
              → {r.suggested_action}
            </p>
          </li>
        ))}
      </ul>
    </div>
  );
}
