"use client";

import type { RiskClassification } from "@/lib/api";

interface RiskBadgeProps {
  risk: RiskClassification | null;
}

export function RiskBadge({ risk }: RiskBadgeProps) {
  if (!risk) return null;

  const colors: Record<string, string> = {
    low: "bg-emerald-100 text-emerald-800 border-emerald-200",
    medium: "bg-amber-100 text-amber-800 border-amber-200",
    high: "bg-orange-100 text-orange-800 border-orange-200",
    critical: "bg-red-100 text-red-800 border-red-200",
  };
  const c = colors[risk.overall_risk] ?? "bg-slate-100 text-slate-800";

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
      <h3 className="mb-3 font-semibold text-slate-800">Risk Classification</h3>
      <div className="flex flex-wrap items-center gap-3">
        <span
          className={`rounded-lg border px-3 py-1.5 font-medium capitalize ${c}`}
        >
          {risk.overall_risk} Risk
        </span>
        <span className="text-sm text-slate-500">Score: {risk.risk_score}/100</span>
      </div>
      {Object.keys(risk.step_risks).length > 0 && (
        <div className="mt-3">
          <div className="text-xs font-medium text-slate-500">Per-step risk</div>
          <div className="mt-1 flex flex-wrap gap-2">
            {Object.entries(risk.step_risks).map(([step, r]) => (
              <span
                key={step}
                className={`rounded px-2 py-0.5 text-xs ${
                  r.level === "high"
                    ? "bg-red-50 text-red-700"
                    : r.level === "medium"
                      ? "bg-amber-50 text-amber-700"
                      : "bg-slate-50 text-slate-600"
                }`}
              >
                {step}: {r.level}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
