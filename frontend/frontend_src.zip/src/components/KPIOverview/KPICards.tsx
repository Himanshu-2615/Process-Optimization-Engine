"use client";

import type { AnalysisResult } from "@/lib/api";

interface KPICardsProps {
  analysis: AnalysisResult | null;
}

export function KPICards({ analysis }: KPICardsProps) {
  if (!analysis) {
    return (
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        {[1, 2, 3, 4].map((i) => (
          <div
            key={i}
            className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm animate-pulse"
          >
            <div className="h-4 w-24 rounded bg-slate-200" />
            <div className="mt-2 h-8 w-16 rounded bg-slate-200" />
          </div>
        ))}
      </div>
    );
  }

  const cards = [
    {
      label: "Cycle Time",
      value: `${analysis.cycle_time_minutes} min`,
      sub: "Critical path",
      color: "border-l-blue-500",
    },
    {
      label: "Throughput",
      value: `${analysis.throughput_per_hour.toFixed(2)}/hr`,
      sub: "Units per hour",
      color: "border-l-emerald-500",
    },
    {
      label: "Daily Cost",
      value: `₹${analysis.cost_breakdown.daily_cost.toLocaleString()}`,
      sub: "Monthly: ₹" + analysis.cost_breakdown.monthly_cost.toLocaleString(),
      color: "border-l-amber-500",
    },
    {
      label: "SLA Risk Score",
      value: `${analysis.sla_risk_score}/100`,
      sub: analysis.sla_risk_score > 50 ? "High risk" : "Low risk",
      color: analysis.sla_risk_score > 50 ? "border-l-red-500" : "border-l-green-500",
    },
  ];

  return (
    <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
      {cards.map((card) => (
        <div
          key={card.label}
          className={`rounded-xl border-l-4 border border-slate-200 bg-white p-4 shadow-sm ${card.color}`}
        >
          <div className="text-sm font-medium text-slate-500">{card.label}</div>
          <div className="mt-1 text-xl font-bold text-slate-800">{card.value}</div>
          <div className="mt-0.5 text-xs text-slate-400">{card.sub}</div>
        </div>
      ))}
    </div>
  );
}
