"use client";

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import type { SimulationResult } from "@/lib/api";

interface SimulationResultsProps {
  result: SimulationResult | null;
}

export function SimulationResults({ result }: SimulationResultsProps) {
  if (!result) {
    return (
      <div className="rounded-xl border border-slate-200 bg-white p-6 text-center text-slate-500">
        Run a simulation to see before vs after comparison
      </div>
    );
  }

  const chartData = [
    { name: "Cycle Time (min)", Before: result.original_cycle_time, After: result.new_cycle_time },
    { name: "Daily Cost (₹)", Before: result.original_daily_cost, After: result.new_daily_cost },
  ];

  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
        <h3 className="mb-4 font-semibold text-slate-800">Before vs After</h3>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          <div className="rounded-lg bg-slate-50 p-3">
            <div className="text-xs text-slate-500">Time Saved</div>
            <div className="text-lg font-bold text-emerald-600">
              {result.time_saved_minutes} min
            </div>
          </div>
          <div className="rounded-lg bg-slate-50 p-3">
            <div className="text-xs text-slate-500">Daily Cost Saved</div>
            <div className="text-lg font-bold text-emerald-600">
              ₹{result.cost_saved_daily.toLocaleString()}
            </div>
          </div>
          <div className="rounded-lg bg-slate-50 p-3">
            <div className="text-xs text-slate-500">Annual Savings</div>
            <div className="text-lg font-bold text-emerald-600">
              ₹{result.annual_savings.toLocaleString()}
            </div>
          </div>
          <div className="rounded-lg bg-slate-50 p-3">
            <div className="text-xs text-slate-500">ROI</div>
            <div className="text-lg font-bold text-indigo-600">
              {result.roi != null ? `${(result.roi * 100).toFixed(0)}%` : "N/A"}
            </div>
          </div>
        </div>
        {result.payback_months != null && (
          <div className="mt-3 text-sm text-slate-600">
            Payback period: <strong>{result.payback_months.toFixed(1)} months</strong>
          </div>
        )}
      </div>
      <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
        <h3 className="mb-4 font-semibold text-slate-800">Comparison Chart</h3>
        <div className="h-[250px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip formatter={(v: number | undefined) => (v != null ? v.toFixed(2) : "")} />
              <Legend />
              <Bar dataKey="Before" fill="#94a3b8" radius={[4, 4, 0, 0]} />
              <Bar dataKey="After" fill="#6366f1" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
