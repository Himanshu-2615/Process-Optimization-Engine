"use client";

import { useState } from "react";
import type { Process, SimulationRequest, SimulationResult } from "@/lib/api";

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

interface SimulationFormProps {
  process: Process;
  onResult: (result: SimulationResult) => void;
}

const SIM_TYPES = [
  { value: "reduce_duration", label: "Reduce Duration" },
  { value: "add_resource", label: "Add Resource" },
  { value: "automate", label: "Automate Step" },
] as const;

export function SimulationForm({ process, onResult }: SimulationFormProps) {
  const [simType, setSimType] = useState<SimulationRequest["simulation_type"]>("reduce_duration");
  const [stepId, setStepId] = useState(process.steps[0]?.id ?? 0);
  const [reductionPercent, setReductionPercent] = useState(40);
  const [resourcesToAdd, setResourcesToAdd] = useState(1);
  const [newDuration, setNewDuration] = useState(60);
  const [newCost, setNewCost] = useState(10);
  const [implCost, setImplCost] = useState(50000);
  const [revenuePerUnit, setRevenuePerUnit] = useState(500);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const runSimulation = async () => {
    setLoading(true);
    setError(null);
    const req: SimulationRequest = {
      simulation_type: simType,
      step_id: stepId,
      implementation_cost: implCost,
      revenue_per_unit: revenuePerUnit,
    };
    if (simType === "reduce_duration") req.duration_reduction_percent = reductionPercent;
    if (simType === "add_resource") req.resources_to_add = resourcesToAdd;
    if (simType === "automate") {
      req.new_duration_minutes = newDuration;
      req.new_cost_per_execution = newCost;
    }

    try {
      const res = await fetch(
        `${API_BASE}/api/processes/${process.id}/simulate`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(req),
        }
      );
      if (!res.ok) throw new Error(await res.text());
      const data: SimulationResult = await res.json();
      onResult(data);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Simulation failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
      <h3 className="mb-4 font-semibold text-slate-800">Optimization Simulation</h3>
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-600">Simulation Type</label>
          <select
            value={simType}
            onChange={(e) => setSimType(e.target.value as SimulationRequest["simulation_type"])}
            className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2"
          >
            {SIM_TYPES.map((t) => (
              <option key={t.value} value={t.value}>
                {t.label}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-600">Step</label>
          <select
            value={stepId}
            onChange={(e) => setStepId(Number(e.target.value))}
            className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2"
          >
            {process.steps.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </div>
        {simType === "reduce_duration" && (
          <div>
            <label className="block text-sm font-medium text-slate-600">
              Duration Reduction (%)
            </label>
            <input
              type="number"
              value={reductionPercent}
              onChange={(e) => setReductionPercent(Number(e.target.value))}
              min={1}
              max={99}
              className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2"
            />
          </div>
        )}
        {simType === "add_resource" && (
          <div>
            <label className="block text-sm font-medium text-slate-600">Resources to Add</label>
            <input
              type="number"
              value={resourcesToAdd}
              onChange={(e) => setResourcesToAdd(Number(e.target.value))}
              min={1}
              className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2"
            />
          </div>
        )}
        {simType === "automate" && (
          <>
            <div>
              <label className="block text-sm font-medium text-slate-600">New Duration (min)</label>
              <input
                type="number"
                value={newDuration}
                onChange={(e) => setNewDuration(Number(e.target.value))}
                min={0}
                className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-600">New Cost/Execution</label>
              <input
                type="number"
                value={newCost}
                onChange={(e) => setNewCost(Number(e.target.value))}
                min={0}
                className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2"
              />
            </div>
          </>
        )}
        <div>
          <label className="block text-sm font-medium text-slate-600">
            Implementation Cost (₹)
          </label>
          <input
            type="number"
            value={implCost}
            onChange={(e) => setImplCost(Number(e.target.value))}
            min={0}
            className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-600">
            Revenue per Unit (₹)
          </label>
          <input
            type="number"
            value={revenuePerUnit}
            onChange={(e) => setRevenuePerUnit(Number(e.target.value))}
            min={0}
            className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2"
          />
        </div>
        {error && <div className="text-sm text-red-600">{error}</div>}
        <button
          onClick={runSimulation}
          disabled={loading}
          className="w-full rounded-lg bg-indigo-600 px-4 py-2 font-medium text-white hover:bg-indigo-700 disabled:opacity-50"
        >
          {loading ? "Running..." : "Run Simulation"}
        </button>
      </div>
    </div>
  );
}
