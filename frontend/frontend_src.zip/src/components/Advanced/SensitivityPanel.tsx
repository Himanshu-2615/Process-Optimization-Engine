"use client";

import { useState } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import type { Process } from "@/lib/api";

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

interface SensitivityPanelProps {
  process: Process;
  revenuePerUnit?: number;
}

export function SensitivityPanel({ process, revenuePerUnit }: SensitivityPanelProps) {
  const [stepId, setStepId] = useState(process.steps[0]?.id ?? 0);
  const [param, setParam] = useState("duration_minutes");
  const [minMult, setMinMult] = useState(0.8);
  const [maxMult, setMaxMult] = useState(1.2);
  const [data, setData] = useState<Array<Record<string, number | string>> | null>(null);
  const [loading, setLoading] = useState(false);

  const runAnalysis = async () => {
    setLoading(true);
    try {
      const q = new URLSearchParams();
      if (revenuePerUnit != null) q.set("revenue_per_unit", String(revenuePerUnit));
      const res = await fetch(
        `${API_BASE}/api/processes/${process.id}/sensitivity?${q}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            step_id: stepId,
            param,
            min_multiplier: minMult,
            max_multiplier: maxMult,
            num_points: 11,
          }),
        }
      );
      if (!res.ok) throw new Error(await res.text());
      const result = await res.json();
      setData(result);
    } catch (e) {
      setData(null);
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
      <h3 className="mb-4 font-semibold text-slate-800">Sensitivity Analysis</h3>
      <div className="mb-4 flex flex-wrap gap-3">
        <div>
          <label className="block text-xs text-slate-500">Step</label>
          <select
            value={stepId}
            onChange={(e) => setStepId(Number(e.target.value))}
            className="rounded border border-slate-300 px-2 py-1.5 text-sm"
          >
            {process.steps.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-xs text-slate-500">Parameter</label>
          <select
            value={param}
            onChange={(e) => setParam(e.target.value)}
            className="rounded border border-slate-300 px-2 py-1.5 text-sm"
          >
            <option value="duration_minutes">Duration</option>
            <option value="cost_per_execution">Cost</option>
            <option value="resource_count">Resources</option>
            <option value="executions_per_day">Executions/day</option>
          </select>
        </div>
        <div>
          <label className="block text-xs text-slate-500">Range</label>
          <div className="flex gap-1">
            <input
              type="number"
              value={minMult}
              onChange={(e) => setMinMult(Number(e.target.value))}
              step={0.1}
              className="w-16 rounded border border-slate-300 px-2 py-1.5 text-sm"
            />
            <span className="self-center text-slate-400">–</span>
            <input
              type="number"
              value={maxMult}
              onChange={(e) => setMaxMult(Number(e.target.value))}
              step={0.1}
              className="w-16 rounded border border-slate-300 px-2 py-1.5 text-sm"
            />
          </div>
        </div>
        <div className="flex items-end">
          <button
            onClick={runAnalysis}
            disabled={loading}
            className="rounded bg-indigo-600 px-4 py-1.5 text-sm text-white hover:bg-indigo-700 disabled:opacity-50"
          >
            {loading ? "Running..." : "Analyze"}
          </button>
        </div>
      </div>
      {data && data.length > 0 && (
        <div className="h-[250px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="multiplier" />
              <YAxis yAxisId="left" />
              <YAxis yAxisId="right" orientation="right" />
              <Tooltip />
              <Legend />
              <Line
                yAxisId="left"
                type="monotone"
                dataKey="cycle_time_minutes"
                stroke="#6366f1"
                name="Cycle Time (min)"
                dot={false}
              />
              <Line
                yAxisId="right"
                type="monotone"
                dataKey="daily_cost"
                stroke="#10b981"
                name="Daily Cost"
                dot={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
}
