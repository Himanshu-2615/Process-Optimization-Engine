"use client";

import { useState } from "react";
import type { Process } from "@/lib/api";

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

interface MonteCarloResult {
  iterations: number;
  variation_percent: number;
  cycle_time: { mean: number; std: number; min: number; max: number; p50: number; p90: number; p95: number };
  daily_cost: { mean: number; std: number; min: number; max: number; p50: number; p90: number; p95: number };
}

interface MonteCarloPanelProps {
  process: Process;
  revenuePerUnit?: number;
}

export function MonteCarloPanel({ process, revenuePerUnit }: MonteCarloPanelProps) {
  const [iterations, setIterations] = useState(500);
  const [variation, setVariation] = useState(20);
  const [result, setResult] = useState<MonteCarloResult | null>(null);
  const [loading, setLoading] = useState(false);

  const run = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      params.set("num_iterations", String(iterations));
      params.set("variation_percent", String(variation));
      if (revenuePerUnit != null) params.set("revenue_per_unit", String(revenuePerUnit));
      const res = await fetch(
        `${API_BASE}/api/processes/${process.id}/monte-carlo?${params}`,
        { method: "POST" }
      );
      if (!res.ok) throw new Error(await res.text());
      setResult(await res.json());
    } catch (e) {
      setResult(null);
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
      <h3 className="mb-4 font-semibold text-slate-800">Monte Carlo Simulation</h3>
      <p className="mb-4 text-sm text-slate-600">
        Simulate delay variability: randomly vary step durations by ±X% to get distribution stats.
      </p>
      <div className="mb-4 flex flex-wrap gap-4">
        <div>
          <label className="block text-xs text-slate-500">Iterations</label>
          <input
            type="number"
            value={iterations}
            onChange={(e) => setIterations(Number(e.target.value))}
            min={100}
            max={2000}
            step={100}
            className="w-24 rounded border border-slate-300 px-2 py-1.5 text-sm"
          />
        </div>
        <div>
          <label className="block text-xs text-slate-500">Variation %</label>
          <input
            type="number"
            value={variation}
            onChange={(e) => setVariation(Number(e.target.value))}
            min={5}
            max={50}
            className="w-20 rounded border border-slate-300 px-2 py-1.5 text-sm"
          />
        </div>
        <div className="flex items-end">
          <button
            onClick={run}
            disabled={loading}
            className="rounded bg-indigo-600 px-4 py-1.5 text-sm text-white hover:bg-indigo-700 disabled:opacity-50"
          >
            {loading ? "Running..." : "Run Simulation"}
          </button>
        </div>
      </div>
      {result && (
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="rounded-lg border border-slate-100 bg-slate-50 p-3">
            <div className="mb-2 font-medium text-slate-700">Cycle Time (min)</div>
            <table className="w-full text-sm">
              <tbody>
                <tr><td>Mean</td><td className="text-right">{result.cycle_time.mean}</td></tr>
                <tr><td>Std Dev</td><td className="text-right">{result.cycle_time.std}</td></tr>
                <tr><td>P50</td><td className="text-right">{result.cycle_time.p50}</td></tr>
                <tr><td>P90</td><td className="text-right">{result.cycle_time.p90}</td></tr>
                <tr><td>P95</td><td className="text-right">{result.cycle_time.p95}</td></tr>
              </tbody>
            </table>
          </div>
          <div className="rounded-lg border border-slate-100 bg-slate-50 p-3">
            <div className="mb-2 font-medium text-slate-700">Daily Cost (₹)</div>
            <table className="w-full text-sm">
              <tbody>
                <tr><td>Mean</td><td className="text-right">{result.daily_cost.mean.toLocaleString()}</td></tr>
                <tr><td>Std Dev</td><td className="text-right">{result.daily_cost.std.toLocaleString()}</td></tr>
                <tr><td>P50</td><td className="text-right">{result.daily_cost.p50.toLocaleString()}</td></tr>
                <tr><td>P90</td><td className="text-right">{result.daily_cost.p90.toLocaleString()}</td></tr>
                <tr><td>P95</td><td className="text-right">{result.daily_cost.p95.toLocaleString()}</td></tr>
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
