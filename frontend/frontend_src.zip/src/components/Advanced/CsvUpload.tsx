"use client";

import { useState, useRef } from "react";
import type { Process } from "@/lib/api";

interface CsvUploadProps {
  onSuccess: (process: Process) => void;
}

const CSV_TEMPLATE = `name,duration_minutes,cost_per_execution,resource_count,sla_limit_minutes,executions_per_day
Step 1,10,5,2,15,50
Step 2,120,50,3,90,50
Step 3,90,30,2,120,50`;

export function CsvUpload({ onSuccess }: CsvUploadProps) {
  const [file, setFile] = useState<File | null>(null);
  const [name, setName] = useState("Imported Process");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

  const handleUpload = async () => {
    if (!file) return;
    setLoading(true);
    setError(null);
    try {
      const form = new FormData();
      form.append("file", file);
      const params = new URLSearchParams();
      params.set("name", name);
      const res = await fetch(`${API_BASE}/api/processes/upload-csv?${params}`, {
        method: "POST",
        body: form,
      });
      if (!res.ok) {
        const err = await res.text();
        throw new Error(err || "Upload failed");
      }
      const process: Process = await res.json();
      onSuccess(process);
      setFile(null);
      setName("Imported Process");
      if (inputRef.current) inputRef.current.value = "";
    } catch (e) {
      setError(e instanceof Error ? e.message : "Upload failed");
    } finally {
      setLoading(false);
    }
  };

  const downloadTemplate = () => {
    const blob = new Blob([CSV_TEMPLATE], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "process_template.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
      <h3 className="mb-4 font-semibold text-slate-800">Upload CSV Process</h3>
      <p className="mb-4 text-sm text-slate-600">
        Upload a CSV with columns: name, duration_minutes, cost_per_execution, resource_count, sla_limit_minutes, executions_per_day
      </p>
      <div className="space-y-3">
        <div>
          <label className="block text-xs text-slate-500">Process name</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full rounded border border-slate-300 px-3 py-2 text-sm"
          />
        </div>
        <div>
          <input
            ref={inputRef}
            type="file"
            accept=".csv"
            onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            className="block w-full text-sm"
          />
        </div>
        {error && <div className="text-sm text-red-600">{error}</div>}
        <div className="flex gap-2">
          <button
            onClick={handleUpload}
            disabled={!file || loading}
            className="rounded bg-indigo-600 px-4 py-2 text-sm text-white hover:bg-indigo-700 disabled:opacity-50"
          >
            {loading ? "Uploading..." : "Upload"}
          </button>
          <button
            onClick={downloadTemplate}
            className="rounded border border-slate-300 px-4 py-2 text-sm text-slate-700 hover:bg-slate-50"
          >
            Download Template
          </button>
        </div>
      </div>
    </div>
  );
}
