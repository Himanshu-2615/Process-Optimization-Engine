"use client";

import { useState } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import type { Process, SimulationRequest } from "@/lib/api";

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

interface ScenarioRow {
  name: string;
  cycle_time: number;
  daily_cost: number;
  time_saved: number;
  cost_saved: number;
  roi: number | null;
}

interface MultiScenarioPanelProps {
  process: Process;
}

const PRESETS = [
  {
    name: "Reduce Manager Approval 40%",
    req: {
      simulation_type: "reduce_duration" as const,
      step_id: 0,
      duration_reduction_percent: 40,
      implementation_cost: 50000,
    },
  },
  {
    name: "Add 1 Resource to Bottleneck",
    req: {
      simulation_type: "add_resource" as const,
      step_id: 0,
      resources_to_add: 1,
      implementation_cost: 100000,
    },
  },
  {
    name: "Automate Step",
    req: {
      simulation_type: "automate" as const,
      step_id: 0,
      new_duration_minutes: 30,
      new_cost_per_execution: 10,
      implementation_cost: 200000,
    },
  },
];

export function MultiScenarioPanel({ process }: MultiScenarioPanelProps) {
  const [results, setResults] = useState<ScenarioRow[] | null>(null);
  const [loading, setLoading] = useState(false);

  const runComparison = async () => {
    setLoading(true);
    try {
      const stepsToUse = process.steps.slice(0, Math.min(3, process.steps.length));
      const scenarios: SimulationRequest[] = stepsToUse.map((s, i) => ({
        simulation_type: "reduce_duration" as const,
        step_id: s.id,
        duration_reduction_percent: 20 + i * 15,
        implementation_cost: 50000,
      }));
      const names = stepsToUse.map((s, i) => `Reduce ${s.name} by ${20 + i * 15}%`);

      const res = await fetch(
        `${API_BASE}/api/processes/multi-scenario/${process.id}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ scenarios, scenario_names: names }),
        }
      );
      if (!res.ok) throw new Error(await res.text());
      const data = await res.json();

      const rows: ScenarioRow[] = data.scenarios
        .filter((x: { result?: unknown }) => x.result)
        .map((x: { name: string; result: { new_cycle_time: number; new_daily_cost: number; time_saved_minutes: number; cost_saved_daily: number; roi: number | null } }) => ({
          name: x.name,
          cycle_time: x.result.new_cycle_time,
          daily_cost: x.result.new_daily_cost,
          time_saved: x.result.time_saved_minutes,
          cost_saved: x.result.cost_saved_daily,
          roi: x.result.roi,
        }));
      setResults(rows);
    } catch (e) {
      setResults(null);
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
      <h3 className="mb-4 font-semibold text-slate-800">Multi-Scenario Comparison</h3>
      <p className="mb-4 text-sm text-slate-600">
        Run multiple optimization scenarios and compare cycle time, cost, and ROI.
      </p>
      <button
        onClick={runComparison}
        disabled={loading}
        className="mb-4 rounded bg-indigo-600 px-4 py-2 text-sm text-white hover:bg-indigo-700 disabled:opacity-50"
      >
        {loading ? "Running..." : "Compare Scenarios"}
      </button>
      {results && results.length > 0 && (
        <>
          <div className="mb-4 h-[220px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={results}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                <YAxis yAxisId="left" />
                <YAxis yAxisId="right" orientation="right" />
                <Tooltip />
                <Legend />
                <Bar yAxisId="left" dataKey="cycle_time" fill="#6366f1" name="Cycle Time (min)" radius={[4, 4, 0, 0]} />
                <Bar yAxisId="right" dataKey="daily_cost" fill="#10b981" name="Daily Cost" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200">
                <th className="py-2 text-left">Scenario</th>
                <th className="py-2 text-right">Time Saved</th>
                <th className="py-2 text-right">Cost Saved</th>
                <th className="py-2 text-right">ROI</th>
              </tr>
            </thead>
            <tbody>
              {results.map((r) => (
                <tr key={r.name} className="border-b border-slate-100">
                  <td className="py-2">{r.name}</td>
                  <td className="text-right">{r.time_saved.toFixed(0)} min</td>
                  <td className="text-right">₹{r.cost_saved.toLocaleString()}</td>
                  <td className="text-right">
                    {r.roi != null ? `${(r.roi * 100).toFixed(0)}%` : "N/A"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </>
      )}
    </div>
  );
}
