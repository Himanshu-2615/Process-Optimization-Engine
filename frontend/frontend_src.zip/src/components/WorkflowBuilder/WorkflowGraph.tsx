"use client";

import { useEffect } from "react";
import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  Node,
  Edge,
  useNodesState,
  useEdgesState,
  BackgroundVariant,
  MarkerType,
  NodeTypes,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import { StepNode, type StepNodeData } from "./StepNode";

const nodeTypes: NodeTypes = { step: StepNode };

interface WorkflowGraphProps {
  process: {
    steps: Array<{
      id: number;
      name: string;
      duration_minutes: number;
      cost_per_execution: number;
      resource_count: number;
      sla_limit_minutes: number | null;
      executions_per_day: number;
    }>;
    dependencies: Array<{ source_step_id: number; target_step_id: number }>;
  };
  bottleneckStepIds?: Set<number>;
  criticalPathSteps?: Set<string>;
}

export function WorkflowGraph({
  process,
  bottleneckStepIds = new Set(),
  criticalPathSteps = new Set(),
}: WorkflowGraphProps) {
  const nodeWidth = 180;
  const nodeHeight = 90;
  const gap = 80;

  const nodes: Node<StepNodeData>[] = process.steps.map((s, i) => {
    const isBottleneck = bottleneckStepIds.has(s.id);
    const isCritical = criticalPathSteps.has(s.name);
    const col = i % 3;
    const row = Math.floor(i / 3);
    return {
      id: String(s.id),
      type: "step",
      position: { x: col * (nodeWidth + gap), y: row * (nodeHeight + gap) },
      data: {
        name: s.name,
        duration_minutes: s.duration_minutes,
        cost_per_execution: s.cost_per_execution,
        executions_per_day: s.executions_per_day,
        isBottleneck,
        isCritical,
      } satisfies StepNodeData,
    };
  });

  const edges: Edge[] = process.dependencies.map((d) => ({
    id: `e-${d.source_step_id}-${d.target_step_id}`,
    source: String(d.source_step_id),
    target: String(d.target_step_id),
    type: "smoothstep",
    markerEnd: { type: MarkerType.ArrowClosed },
    animated: bottleneckStepIds.has(d.source_step_id) || bottleneckStepIds.has(d.target_step_id),
    style: {
      stroke: bottleneckStepIds.has(d.source_step_id) ? "#dc2626" : "#94a3b8",
      strokeWidth: bottleneckStepIds.has(d.source_step_id) ? 2 : 1,
    },
  }));

  const [nodesState, setNodes, onNodesChange] = useNodesState(nodes);
  const [edgesState, setEdges, onEdgesChange] = useEdgesState(edges);

  useEffect(() => {
    setNodes(nodes);
    setEdges(edges);
  }, [
    process.steps.map((s) => s.id).join(","),
    process.dependencies.length,
    [...bottleneckStepIds].join(","),
    [...criticalPathSteps].join(","),
  ]);

  return (
    <div className="h-[500px] w-full rounded-xl border border-slate-200 bg-slate-50">
      <ReactFlow
        nodes={nodesState}
        edges={edgesState}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        nodeTypes={nodeTypes}
        fitView
        fitViewOptions={{ padding: 0.2 }}
      >
        <Background variant={BackgroundVariant.Dots} gap={16} size={1} />
        <Controls />
        <MiniMap nodeStrokeWidth={3} zoomable pannable />
      </ReactFlow>
    </div>
  );
}
