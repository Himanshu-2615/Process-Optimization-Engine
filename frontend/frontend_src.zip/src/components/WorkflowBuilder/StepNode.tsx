"use client";

import { memo } from "react";
import { Handle, Position, type Node, type NodeProps } from "@xyflow/react";

export interface StepNodeData extends Record<string, unknown> {
  name: string;
  duration_minutes: number;
  cost_per_execution: number;
  executions_per_day: number;
  isBottleneck?: boolean;
  isCritical?: boolean;
}

type StepNodeType = Node<StepNodeData, "step">;

function StepNodeComponent({ data }: NodeProps<StepNodeType>) {
  const { name, duration_minutes, cost_per_execution, executions_per_day, isBottleneck, isCritical } = data;
  return (
    <>
      <Handle type="target" position={Position.Top} className="!bg-slate-400" />
      <div
        className={`min-w-[160px] rounded-lg border-2 bg-white p-3 shadow-md ${
          isBottleneck ? "border-red-500" : isCritical ? "border-amber-500" : "border-slate-200"
        }`}
      >
        <div
          className={`font-semibold ${
            isBottleneck ? "text-red-600" : isCritical ? "text-amber-600" : "text-slate-800"
          }`}
        >
          {name}
        </div>
        <div className="mt-1 text-xs text-slate-500">
          {duration_minutes} min · ₹{cost_per_execution} · {executions_per_day}/day
        </div>
        {isBottleneck && (
          <div className="mt-1 text-xs font-medium text-red-600">Bottleneck</div>
        )}
      </div>
      <Handle type="source" position={Position.Bottom} className="!bg-slate-400" />
    </>
  );
}

export const StepNode = memo(StepNodeComponent);
