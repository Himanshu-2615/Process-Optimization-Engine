"use client";

import { useState } from "react";
import { API_BASE, type Process, type ProcessStep } from "@/lib/api";

interface ProcessEditorProps {
  process: Process;
  onUpdate: (updated: Process) => void;
}

export function ProcessEditor({ process: processData, onUpdate }: ProcessEditorProps) {
  const [editProcess, setEditProcess] = useState(false);
  const [name, setName] = useState(processData.name);
  const [description, setDescription] = useState(processData.description ?? "");
  const [editingStep, setEditingStep] = useState<number | null>(null);
  const [stepForm, setStepForm] = useState<Partial<ProcessStep>>({});
  const [saving, setSaving] = useState(false);

  const saveProcess = async () => {
    setSaving(true);
    try {
      const res = await fetch(`${API_BASE}/api/processes/${processData.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, description: description || null }),
      });
      if (!res.ok) throw new Error(await res.text());
      const updated = await res.json();
      onUpdate(updated);
      setEditProcess(false);
    } catch (e) {
      console.error(e);
    } finally {
      setSaving(false);
    }
  };

  const startEditStep = (step: ProcessStep) => {
    setEditingStep(step.id);
    setStepForm({
      name: step.name,
      duration_minutes: step.duration_minutes,
      cost_per_execution: step.cost_per_execution,
      resource_count: step.resource_count,
      sla_limit_minutes: step.sla_limit_minutes,
      executions_per_day: step.executions_per_day,
    });
  };

  const saveStep = async () => {
    if (editingStep == null) return;
    setSaving(true);
    try {
      const res = await fetch(
        `${API_BASE}/api/processes/${processData.id}/steps/${editingStep}`,
        {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(stepForm),
        }
      );
      if (!res.ok) throw new Error(await res.text());
      const updated = await res.json();
      onUpdate(updated);
      setEditingStep(null);
    } catch (e) {
      console.error(e);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
      <div className="mb-4 flex items-center justify-between">
        <h3 className="font-semibold text-slate-800">Edit Process</h3>
        {!editProcess ? (
          <button
            onClick={() => setEditProcess(true)}
            className="text-sm text-indigo-600 hover:underline"
          >
            Edit name & description
          </button>
        ) : (
          <div className="flex gap-2">
            <button
              onClick={saveProcess}
              disabled={saving}
              className="rounded bg-indigo-600 px-3 py-1 text-sm text-white hover:bg-indigo-700 disabled:opacity-50"
            >
              Save
            </button>
            <button
              onClick={() => {
                setEditProcess(false);
                setName(processData.name);
                setDescription(processData.description ?? "");
              }}
              className="rounded border border-slate-300 px-3 py-1 text-sm hover:bg-slate-50"
            >
              Cancel
            </button>
          </div>
        )}
      </div>

      {editProcess && (
        <div className="mb-4 space-y-2">
          <div>
            <label className="block text-xs text-slate-500">Process name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full rounded border border-slate-300 px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs text-slate-500">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={2}
              className="w-full rounded border border-slate-300 px-3 py-2 text-sm"
            />
          </div>
        </div>
      )}

      <div>
        <div className="mb-2 text-sm font-medium text-slate-600">Steps</div>
        <div className="space-y-2">
          {processData.steps.map((step) =>
            editingStep === step.id ? (
              <div
                key={step.id}
                className="rounded-lg border border-indigo-200 bg-indigo-50/50 p-3"
              >
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                  <div>
                    <label className="block text-xs text-slate-500">Name</label>
                    <input
                      value={stepForm.name ?? ""}
                      onChange={(e) =>
                        setStepForm((f) => ({ ...f, name: e.target.value }))
                      }
                      className="w-full rounded border px-2 py-1 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-500">
                      Duration (min)
                    </label>
                    <input
                      type="number"
                      value={stepForm.duration_minutes ?? ""}
                      onChange={(e) =>
                        setStepForm((f) => ({
                          ...f,
                          duration_minutes: Number(e.target.value),
                        }))
                      }
                      min={0}
                      className="w-full rounded border px-2 py-1 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-500">Cost</label>
                    <input
                      type="number"
                      value={stepForm.cost_per_execution ?? ""}
                      onChange={(e) =>
                        setStepForm((f) => ({
                          ...f,
                          cost_per_execution: Number(e.target.value),
                        }))
                      }
                      min={0}
                      className="w-full rounded border px-2 py-1 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-500">
                      Resources
                    </label>
                    <input
                      type="number"
                      value={stepForm.resource_count ?? ""}
                      onChange={(e) =>
                        setStepForm((f) => ({
                          ...f,
                          resource_count: Number(e.target.value),
                        }))
                      }
                      min={1}
                      className="w-full rounded border px-2 py-1 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-500">SLA (min)</label>
                    <input
                      type="number"
                      value={stepForm.sla_limit_minutes ?? ""}
                      onChange={(e) =>
                        setStepForm((f) => ({
                          ...f,
                          sla_limit_minutes: e.target.value
                            ? Number(e.target.value)
                            : null,
                        }))
                      }
                      min={0}
                      placeholder="Optional"
                      className="w-full rounded border px-2 py-1 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-500">
                      Exec/day
                    </label>
                    <input
                      type="number"
                      value={stepForm.executions_per_day ?? ""}
                      onChange={(e) =>
                        setStepForm((f) => ({
                          ...f,
                          executions_per_day: Number(e.target.value),
                        }))
                      }
                      min={1}
                      className="w-full rounded border px-2 py-1 text-sm"
                    />
                  </div>
                </div>
                <div className="mt-2 flex gap-2">
                  <button
                    onClick={saveStep}
                    disabled={saving}
                    className="rounded bg-indigo-600 px-3 py-1 text-sm text-white hover:bg-indigo-700 disabled:opacity-50"
                  >
                    Save
                  </button>
                  <button
                    onClick={() => setEditingStep(null)}
                    className="rounded border px-3 py-1 text-sm hover:bg-slate-50"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <div
                key={step.id}
                className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-slate-100 bg-slate-50 p-3"
              >
                <div>
                  <span className="font-medium text-slate-800">{step.name}</span>
                  <span className="ml-2 text-sm text-slate-500">
                    {step.duration_minutes} min · ₹{step.cost_per_execution} ·{" "}
                    {step.executions_per_day}/day
                  </span>
                </div>
                <button
                  onClick={() => startEditStep(step)}
                  className="text-sm text-indigo-600 hover:underline"
                >
                  Edit
                </button>
              </div>
            )
          )}
        </div>
      </div>
    </div>
  );
}
